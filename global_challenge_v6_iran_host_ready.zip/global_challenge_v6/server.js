const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const Database = require('better-sqlite3');
const crypto = require('crypto');

const app = express();
const db = new Database(process.env.DB_FILE || 'game.sqlite');
const PORT = Number(process.env.PORT || 3000);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';
if (ADMIN_TOKEN.length < 32) { console.error('ADMIN_TOKEN must be at least 32 characters'); process.exit(1); }
app.disable('x-powered-by');
app.use(helmet());
app.use(express.json({limit:'20kb'}));
app.use(rateLimit({windowMs:60000,limit:100,standardHeaders:true,legacyHeaders:false}));
app.use((req,res,next)=>{
  const origin=process.env.ALLOWED_ORIGIN;
  if(origin && req.headers.origin===origin){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');}
  res.setHeader('Access-Control-Allow-Headers','Content-Type,x-admin-token');
  res.setHeader('Access-Control-Allow-Methods','GET,POST,PATCH,OPTIONS');
  if(req.method==='OPTIONS') return res.sendStatus(204);
  next();
});

// Iran-only access: enable this in production behind Cloudflare. The origin server
// must not be directly reachable, otherwise clients could forge CF-IPCountry.
app.use((req,res,next)=>{
  if (process.env.IRAN_ONLY === 'false') return next();
  const countryCode = String(req.get('CF-IPCountry') || '').toUpperCase();
  if (countryCode !== 'IR') return res.status(403).json({error:'این بازی فقط از داخل ایران قابل دسترسی است.'});
  next();
});

db.exec(`
CREATE TABLE IF NOT EXISTS players(id TEXT PRIMARY KEY,nick TEXT NOT NULL,country TEXT NOT NULL,token_hash TEXT NOT NULL UNIQUE,created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS games(id TEXT PRIMARY KEY,player_id TEXT NOT NULL,level INTEGER NOT NULL,hits INTEGER NOT NULL DEFAULT 0,score INTEGER NOT NULL DEFAULT 0,started_at INTEGER NOT NULL,expires_at INTEGER NOT NULL,status TEXT NOT NULL,completed_at INTEGER);
CREATE TABLE IF NOT EXISTS results(player_id TEXT PRIMARY KEY,nick TEXT NOT NULL,country TEXT NOT NULL,score INTEGER NOT NULL,completed_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS payout_requests(id INTEGER PRIMARY KEY AUTOINCREMENT,player_id TEXT NOT NULL,nick TEXT NOT NULL,country TEXT NOT NULL,score INTEGER NOT NULL,status TEXT NOT NULL,created_at INTEGER NOT NULL,reviewed_at INTEGER,payment_reference TEXT);
CREATE TABLE IF NOT EXISTS admin_audit(id INTEGER PRIMARY KEY AUTOINCREMENT,request_id INTEGER NOT NULL,action TEXT NOT NULL,reference TEXT,created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS contact_requests(id INTEGER PRIMARY KEY AUTOINCREMENT,surname TEXT NOT NULL,message TEXT NOT NULL,player_nick TEXT,country TEXT,status TEXT NOT NULL DEFAULT 'new',created_at INTEGER NOT NULL,reviewed_at INTEGER);
`);
const levels=[{hits:5,seconds:30,points:100},{hits:8,seconds:25,points:200},{hits:12,seconds:20,points:300}];
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
function playerAuth(req,res,next){const token=req.body?.token;if(!token)return res.status(401).json({error:'ابتدا ثبت‌نام کن'});const p=db.prepare('SELECT * FROM players WHERE token_hash=?').get(hash(token));if(!p)return res.status(401).json({error:'توکن بازیکن معتبر نیست'});if(p.country!=='ایران')return res.status(403).json({error:'این نسخه فقط برای حساب‌های ثبت‌شده با کشور ایران است؛ دوباره ثبت‌نام کن.'});req.player=p;next();}
function adminAuth(req,res,next){if(!crypto.timingSafeEqual(Buffer.from(hash(req.get('x-admin-token')||'')),Buffer.from(hash(ADMIN_TOKEN))))return res.status(401).json({error:'دسترسی مدیر تأیید نشد'});next();}
function board(){return db.prepare("SELECT player_id,nick,country,score,completed_at FROM results WHERE country='ایران' ORDER BY score DESC,completed_at ASC LIMIT 100").all();}
function target(){return{x:Math.floor(5+Math.random()*85),y:Math.floor(5+Math.random()*75)};}
app.get('/api/health',(req,res)=>res.json({ok:true,service:'iran-challenge-v6',payments:'manual-review-only'}));
app.get('/api/public-config',(req,res)=>res.json({managerPhone:String(process.env.PUBLIC_CONTACT_PHONE||'09911251496').slice(0,30),country:'IR'}));
app.post('/api/contact-request',(req,res)=>{
 const surname=String(req.body.surname||'').trim().replace(/[<>]/g,'').slice(0,60);
 const message=String(req.body.message||'').trim().replace(/[<>]/g,'').slice(0,2000);
 const nick=String(req.body.playerNick||'').trim().slice(0,20)||null;
 const country='ایران';
 if(surname.length<2||message.length<5)return res.status(400).json({error:'نام خانوادگی و متن درخواست را کامل وارد کن.'});
 const result=db.prepare('INSERT INTO contact_requests(surname,message,player_nick,country,created_at) VALUES(?,?,?,?,?)').run(surname,message,nick,country,Date.now());
 res.json({ok:true,id:result.lastInsertRowid,message:'درخواستت با موفقیت برای مدیر ثبت شد.'});
});
app.post('/api/register',(req,res)=>{
 const nick=String(req.body.nick||'').trim().slice(0,20),country='ایران';
 if(nick.length<2)return res.status(400).json({error:'نام مستعار معتبر لازم است'});
 const id=crypto.randomUUID(),token=crypto.randomBytes(32).toString('hex');
 db.prepare('INSERT INTO players(id,nick,country,token_hash,created_at) VALUES(?,?,?,?,?)').run(id,nick,country,hash(token),Date.now());
 res.json({player:{id,nick,country,token}});
});
app.get('/api/leaderboard',(req,res)=>res.json({rows:board().map(({player_id,...r})=>r)}));
app.post('/api/game/start',playerAuth,(req,res)=>{
 const level=Number(req.body.level);if(!Number.isInteger(level)||level<0||level>2)return res.status(400).json({error:'مرحله نامعتبر است'});
 if(level>0){const prior=db.prepare("SELECT status FROM games WHERE player_id=? AND level=? AND status='completed' ORDER BY completed_at DESC LIMIT 1").get(req.player.id,level-1);if(!prior)return res.status(403).json({error:'ابتدا مرحله قبلی را کامل کن'});}
 const c=levels[level],id=crypto.randomUUID(),now=Date.now();db.prepare('INSERT INTO games(id,player_id,level,hits,score,started_at,expires_at,status) VALUES(?,?,?,0,0,?,?,?)').run(id,req.player.id,level,now,now+c.seconds*1000,'active');res.json({session:{id},seconds:c.seconds,target:target()});
});
app.post('/api/game/hit',playerAuth,(req,res)=>{
 const g=db.prepare('SELECT * FROM games WHERE id=? AND player_id=?').get(req.body.sessionId,req.player.id);if(!g||g.status!=='active')return res.status(400).json({error:'بازی فعال پیدا نشد'});
 const now=Date.now(),c=levels[g.level];if(now>g.expires_at){db.prepare("UPDATE games SET status='expired' WHERE id=?").run(g.id);return res.status(400).json({error:'زمان مرحله تمام شده'});}
 if(now-g.started_at<(g.hits+1)*350)return res.status(429).json({error:'خیلی سریع؛ دوباره با سرعت معمولی تلاش کن'});
 const hits=g.hits+1,score=Math.round(hits*c.points/c.hits),done=hits>=c.hits;
 db.prepare('UPDATE games SET hits=?,score=?,status=?,completed_at=? WHERE id=?').run(hits,score,done?'completed':'active',done?now:null,g.id);
 if(done&&g.level===2){const total=db.prepare("SELECT SUM(score) total FROM games WHERE player_id=? AND status='completed'").get(req.player.id).total||0;db.prepare('INSERT INTO results(player_id,nick,country,score,completed_at) VALUES(?,?,?,?,?) ON CONFLICT(player_id) DO UPDATE SET nick=excluded.nick,country=excluded.country,score=excluded.score,completed_at=excluded.completed_at').run(req.player.id,req.player.nick,req.player.country,total,now);}
 res.json({score,completed:done,nextLevel:done&&g.level<2?g.level+1:null,target:done?null:target()});
});
app.post('/api/game/abort',playerAuth,(req,res)=>{db.prepare("UPDATE games SET status='aborted' WHERE id=? AND player_id=? AND status='active'").run(req.body.sessionId,req.player.id);res.json({ok:true});});
app.post('/api/payout/request',playerAuth,(req,res)=>{
 const top=board()[0];if(!top||top.player_id!==req.player.id)return res.status(403).json({error:'فقط نفر اول جدول می‌تواند درخواست بررسی جایزه بدهد.'});
 const exists=db.prepare("SELECT id FROM payout_requests WHERE player_id=? AND status IN ('pending','reviewed')").get(req.player.id);if(exists)return res.status(409).json({error:'درخواست بررسی قبلی هنوز باز است'});
 db.prepare('INSERT INTO payout_requests(player_id,nick,country,score,status,created_at) VALUES(?,?,?,?,?,?)').run(req.player.id,req.player.nick,req.player.country,top.score,'pending',Date.now());
 res.json({message:'درخواست بررسی ثبت شد؛ این پیام تأیید برنده یا پرداخت پول نیست.'});
});
app.get('/api/admin/requests',adminAuth,(req,res)=>res.json({requests:db.prepare('SELECT id,nick,country,score,status,created_at,reviewed_at FROM payout_requests ORDER BY id DESC LIMIT 200').all()}));
app.get('/api/admin/contact-requests',adminAuth,(req,res)=>res.json({requests:db.prepare('SELECT id,surname,message,player_nick,country,status,created_at FROM contact_requests ORDER BY id DESC LIMIT 300').all()}));
app.patch('/api/admin/contact-requests/:id',adminAuth,(req,res)=>{
 const id=Number(req.params.id),status=String(req.body.status||'');
 if(!Number.isSafeInteger(id)||id<1||!['seen','closed'].includes(status))return res.status(400).json({error:'شناسه یا وضعیت نامعتبر است'});
 const r=db.prepare('UPDATE contact_requests SET status=?,reviewed_at=? WHERE id=?').run(status,Date.now(),id);
 if(!r.changes)return res.status(404).json({error:'درخواست پیدا نشد'});
 res.json({ok:true,status});
});
app.patch('/api/admin/requests/:id',adminAuth,(req,res)=>{
 const id=Number(req.params.id),status=String(req.body.status||'');if(!Number.isSafeInteger(id)||id<1)return res.status(400).json({error:'شناسه نامعتبر است'});
 if(!['reviewed','rejected'].includes(status))return res.status(400).json({error:'وضعیت نامعتبر است؛ پرداخت واقعی باید خارج از این سامانه انجام و جداگانه ثبت شود.'});
 const r=db.prepare('UPDATE payout_requests SET status=?,reviewed_at=? WHERE id=?').run(status,Date.now(),id);if(!r.changes)return res.status(404).json({error:'درخواست پیدا نشد'});
 db.prepare('INSERT INTO admin_audit(request_id,action,created_at) VALUES(?,?,?)').run(id,status,Date.now());res.json({ok:true,status});
});
// Serve the game from the same HTTPS origin as the API. This avoids the
// localhost/CORS failure when players open the hosted site on their phones.
app.use(express.static(__dirname, { extensions: ['html'] }));
app.get('*', (req,res)=>res.sendFile(require('path').join(__dirname,'index.html')));
app.listen(PORT,()=>console.log(`Iran Challenge v6 listening on ${PORT}`));
